var unionanswer__t =
[
    [ "float_value", "unionanswer__t.html#afb90c9b49b924a85a3cf6fec5e65955c", null ],
    [ "int_value", "unionanswer__t.html#a073a059d62ed1a83d90d328aec3099ca", null ],
    [ "string_value", "unionanswer__t.html#a3649b3d2e3ecb442bba14a59a87b3177", null ]
];