var unionanswer__t =
[
    [ "float_value", "unionanswer__t.html#a4746ca4b821d32287c79da0e488933fa", null ],
    [ "int_value", "unionanswer__t.html#aa8ec4a02684f8894d9a996497f5c4522", null ],
    [ "string_value", "unionanswer__t.html#a46bf31538724d946cb38462ef97eb0b4", null ]
];