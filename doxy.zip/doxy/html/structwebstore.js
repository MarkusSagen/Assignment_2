var structwebstore =
[
    [ "cart", "structwebstore.html#ae559b6ad45341d95dff6083bf68309a9", null ],
    [ "hash", "structwebstore.html#a49e108cb7142dd8038f10232a0fd2773", null ],
    [ "merch", "structwebstore.html#a50af87ea68cc5cf98ce8c84fcb51772a", null ]
];