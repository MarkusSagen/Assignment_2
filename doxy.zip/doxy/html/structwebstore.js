var structwebstore =
[
    [ "cart", "structwebstore.html#a0757bd927c46559e3599b94e8f8ed6ab", null ],
    [ "hash", "structwebstore.html#a54899e71740555bd23832b053e9ede0d", null ],
    [ "merch", "structwebstore.html#ae7b03fabfea4663543ecd548e55f915a", null ]
];