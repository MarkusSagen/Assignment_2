var searchData=
[
  ['last',['last',['../structlist.html#aa84133359bab9379d8655534244b0527',1,'list']]],
  ['location',['location',['../structstock.html#a6a0d5603410d5eda93c0ff341966cce1',1,'stock']]]
];
