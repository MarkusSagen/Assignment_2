var searchData=
[
  ['add_5fmerch',['add_merch',['../user__interface_8c.html#a0286e89a190965c11b14ed550194a048',1,'user_interface.c']]],
  ['add_5fto_5fcart',['add_to_cart',['../user__interface_8c.html#a044d2473c70a723941a03e38f4f1e037',1,'user_interface.c']]],
  ['ask_5fquestion',['ask_question',['../utils_8c.html#a24c365d4b7d3e92463d07a653db24127',1,'ask_question(char *question, char *error_msg, check_func check):&#160;utils.c'],['../utils_8h.html#a24c365d4b7d3e92463d07a653db24127',1,'ask_question(char *question, char *error_msg, check_func check):&#160;utils.c']]]
];
