var searchData=
[
  ['delete_5fcart',['delete_cart',['../business__logic_8c.html#ad3e6b3f38768a19afe9f52187906bb0f',1,'business_logic.c']]],
  ['delete_5fmerch',['delete_merch',['../business__logic_8c.html#ac2af44c7c7839d7d6368c9d80dad779c',1,'business_logic.c']]],
  ['description',['description',['../structmerch.html#a8444d6e0dfe2bbab0b5e7b24308f1559',1,'merch']]],
  ['destroy_5fbucket',['destroy_bucket',['../hash__table_8c.html#acce8330d4229fb6a8d5c6bbe30d8154f',1,'hash_table.c']]],
  ['dummy',['dummy',['../structioopm__list__iterator.html#a50d6469cd82048a0d8fe304ae0938f6d',1,'ioopm_list_iterator']]]
];
