var searchData=
[
  ['amount',['amount',['../structstock.html#a14236de313193a14b4dbdf442bcf2bb9',1,'stock::amount()'],['../structcart__item.html#a14236de313193a14b4dbdf442bcf2bb9',1,'cart_item::amount()']]],
  ['available',['available',['../structmerch.html#a6a37485bfdca8f2d8b517b6b08cde1b3',1,'merch']]]
];
