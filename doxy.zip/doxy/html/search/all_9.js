var searchData=
[
  ['key',['key',['../structentry.html#aedce9ae9cd2b7d0f6371b1c9ef5a847e',1,'entry']]]
];
