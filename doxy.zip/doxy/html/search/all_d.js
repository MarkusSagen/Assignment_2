var searchData=
[
  ['p',['p',['../unionelem.html#a117104b82864d3b23ec174af6d392709',1,'elem']]],
  ['price',['price',['../structmerch.html#aef7c2446a93a7dc07f65981daf37fa65',1,'merch']]]
];
