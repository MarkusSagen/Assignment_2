var searchData=
[
  ['s',['s',['../unionelem.html#ab51cd24d34f6509eafb5e059f4c7d10e',1,'elem']]],
  ['show_5fstock',['show_stock',['../user__interface_8c.html#a081d118f56a1dd8862e64859c477eeeb',1,'user_interface.c']]],
  ['show_5fstock_5faux',['show_stock_aux',['../business__logic_8c.html#a921fa6711ac15f28f1653f4292818dff',1,'show_stock_aux(webstore_t *webstore):&#160;business_logic.c'],['../business__logic_8h.html#a921fa6711ac15f28f1653f4292818dff',1,'show_stock_aux(webstore_t *webstore):&#160;business_logic.c']]],
  ['size',['size',['../structhash__table.html#a439227feff9d7f55384e8780cfc2eb82',1,'hash_table::size()'],['../structlist.html#a439227feff9d7f55384e8780cfc2eb82',1,'list::size()']]],
  ['stock',['stock',['../structstock.html',1,'webstore_stock_t'],['../structmerch.html#aa2f377dbb4b0ed26d7cd817be60f70dd',1,'merch::stock()']]],
  ['str_5fcmp',['str_cmp',['../utils_8c.html#a25396a0052f0802f8bed438457984c5f',1,'str_cmp(char *in, char *cmp):&#160;utils.c'],['../utils_8h.html#a3d0e38871fd3ef4d473e74ac598ad800',1,'str_cmp(char *str_in, char *str_ref):&#160;utils.c']]],
  ['string_5fsum_5fhash',['string_sum_hash',['../business__logic_8c.html#abb4b99f8bc56b38de1a52064868b1987',1,'business_logic.c']]],
  ['string_5fvalue',['string_value',['../unionanswer__t.html#a3649b3d2e3ecb442bba14a59a87b3177',1,'answer_t']]]
];
