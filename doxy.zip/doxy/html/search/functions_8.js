var searchData=
[
  ['list_5fmerch',['list_merch',['../user__interface_8c.html#aea685f065401ac88d8225f7f7a81480e',1,'user_interface.c']]],
  ['list_5fmerch_5faux',['list_merch_aux',['../business__logic_8c.html#ab26b804a4cf43a95024bf5db992b0e77',1,'list_merch_aux(webstore_merch_t **merch):&#160;business_logic.c'],['../business__logic_8h.html#ab26b804a4cf43a95024bf5db992b0e77',1,'list_merch_aux(webstore_merch_t **merch):&#160;business_logic.c']]]
];
