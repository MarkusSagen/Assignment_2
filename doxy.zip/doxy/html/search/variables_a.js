var searchData=
[
  ['merch',['merch',['../structwebstore.html#ae7b03fabfea4663543ecd548e55f915a',1,'webstore::merch()'],['../structcart__item.html#ae7b03fabfea4663543ecd548e55f915a',1,'cart_item::merch()']]]
];
