var searchData=
[
  ['get_5fmerch',['get_merch',['../business__logic_8c.html#a85c584046682f54ead0e8e38c971a584',1,'get_merch(webstore_t *webstore):&#160;business_logic.c'],['../business__logic_8h.html#a85c584046682f54ead0e8e38c971a584',1,'get_merch(webstore_t *webstore):&#160;business_logic.c']]]
];
