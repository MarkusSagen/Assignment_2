var searchData=
[
  ['description',['description',['../structmerch.html#a8444d6e0dfe2bbab0b5e7b24308f1559',1,'merch']]],
  ['dummy',['dummy',['../structioopm__list__iterator.html#a50d6469cd82048a0d8fe304ae0938f6d',1,'ioopm_list_iterator']]]
];
