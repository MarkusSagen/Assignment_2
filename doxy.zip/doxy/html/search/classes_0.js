var searchData=
[
  ['answer_5ft',['answer_t',['../unionanswer__t.html',1,'']]]
];
