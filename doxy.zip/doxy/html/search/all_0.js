var searchData=
[
  ['add_5fmerch',['add_merch',['../user__interface_8c.html#a0286e89a190965c11b14ed550194a048',1,'user_interface.c']]],
  ['add_5fto_5fcart',['add_to_cart',['../user__interface_8c.html#a044d2473c70a723941a03e38f4f1e037',1,'user_interface.c']]],
  ['amount',['amount',['../structstock.html#a14236de313193a14b4dbdf442bcf2bb9',1,'stock::amount()'],['../structcart__item.html#a14236de313193a14b4dbdf442bcf2bb9',1,'cart_item::amount()']]],
  ['answer_5ft',['answer_t',['../unionanswer__t.html',1,'']]],
  ['ask_5fquestion',['ask_question',['../utils_8c.html#a24c365d4b7d3e92463d07a653db24127',1,'ask_question(char *question, char *error_msg, check_func check):&#160;utils.c'],['../utils_8h.html#a24c365d4b7d3e92463d07a653db24127',1,'ask_question(char *question, char *error_msg, check_func check):&#160;utils.c']]],
  ['available',['available',['../structmerch.html#a6a37485bfdca8f2d8b517b6b08cde1b3',1,'merch']]],
  ['assignment_5f2',['Assignment_2',['../md___users__mk3_johnson__downloads__assignment_2-master2__r_e_a_d_m_e.html',1,'']]]
];
