var searchData=
[
  ['name',['name',['../structmerch.html#a5ac083a645d964373f022d03df4849c8',1,'merch']]],
  ['next',['next',['../structmerch.html#aee045b2f665b2a73b970154ffee31606',1,'merch::next()'],['../structstock.html#a4798c719496e2c60a1ccb73ebec7108c',1,'stock::next()'],['../structcart__item.html#a5e2b15421ef78d5a423b9e19ee1631a4',1,'cart_item::next()'],['../structcart.html#a2165a556fdff3918c9de2ffdcf849158',1,'cart::next()'],['../structentry.html#ae765a567349b72aada7ce353b1af4983',1,'entry::next()'],['../structlist.html#af05e1662817f5aa024ad7148177ffd8c',1,'list::next()']]]
];
