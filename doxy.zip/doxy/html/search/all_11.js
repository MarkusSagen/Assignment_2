var searchData=
[
  ['value',['value',['../structentry.html#a8e0c270a14cc4511175c78480705695c',1,'entry::value()'],['../structlist.html#a8e0c270a14cc4511175c78480705695c',1,'list::value()']]]
];
