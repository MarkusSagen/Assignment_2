var searchData=
[
  ['webstore_5flist_5flen',['webstore_list_len',['../business__logic_8c.html#ad6e974458818330ffb8aa1a45e5d9ae2',1,'webstore_list_len():&#160;business_logic.c'],['../main_8c.html#ad6e974458818330ffb8aa1a45e5d9ae2',1,'webstore_list_len():&#160;main.c'],['../user__interface_8c.html#ad6e974458818330ffb8aa1a45e5d9ae2',1,'webstore_list_len():&#160;user_interface.c']]]
];
