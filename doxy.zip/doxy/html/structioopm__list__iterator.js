var structioopm__list__iterator =
[
    [ "current", "structioopm__list__iterator.html#a6f323b3acdd71542ac517270d659f246", null ],
    [ "dummy", "structioopm__list__iterator.html#a50d6469cd82048a0d8fe304ae0938f6d", null ]
];