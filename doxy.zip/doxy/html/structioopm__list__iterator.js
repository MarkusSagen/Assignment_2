var structioopm__list__iterator =
[
    [ "current", "structioopm__list__iterator.html#a4caae2ed71396591db9eab22e0e8a093", null ],
    [ "dummy", "structioopm__list__iterator.html#a275e358eafd46cb4fa77b626cc75ba39", null ]
];