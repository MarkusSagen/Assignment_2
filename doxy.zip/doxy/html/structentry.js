var structentry =
[
    [ "hash", "structentry.html#aee97b634948f281f9377f7465fbd60f5", null ],
    [ "key", "structentry.html#a33be70c883e1fb2fce9137ea1f8b293a", null ],
    [ "next", "structentry.html#ab539f27578156b17f663482d930f262a", null ],
    [ "value", "structentry.html#a2b544be8f98e97e655e77688e184816d", null ]
];