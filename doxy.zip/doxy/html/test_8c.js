var test_8c =
[
    [ "clear_entries", "test_8c.html#a3036d9ca0114b3b9a79190f50ca5bfdc", null ],
    [ "init_entries", "test_8c.html#a1609d9398fbfaffef9f17dca07addb2a", null ],
    [ "main", "test_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "webstore_add_merch_test", "test_8c.html#abc704f277c698b88b266e0bcb4b536b2", null ],
    [ "webstore_add_to_cart_test", "test_8c.html#ac36e28fd9742dcbe83f3285726ac981f", null ],
    [ "webstore_calculate_cost_test", "test_8c.html#ae8e7e352a85a2c3c334f471ff10350aa", null ],
    [ "webstore_checkout_test", "test_8c.html#a8e9d335a4cd96e602e2db1a2864f24f2", null ],
    [ "webstore_create_cart_test", "test_8c.html#acc3af695addd9a885e3d0628737941a0", null ],
    [ "webstore_edit_merch_test", "test_8c.html#af63ad71f052bf87803b32496cd6c1722", null ],
    [ "webstore_is_item_AUX", "test_8c.html#ad168f0e000a2f4afb599c0a5e5396c19", null ],
    [ "webstore_remove_cart_test", "test_8c.html#aa41cdfda3f09c3dd0027a6f31e070a73", null ],
    [ "webstore_remove_from_cart_test", "test_8c.html#a8b4b88e993acc3a9e5f71b9c0f6f1ef5", null ],
    [ "webstore_remove_merch_test", "test_8c.html#a8442fb9342cccd6197230f7292ef3c65", null ],
    [ "webstore_replenish_test", "test_8c.html#a50b6cbe2ced58aadadd8fd73190287d1", null ]
];