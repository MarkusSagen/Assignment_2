var structcart =
[
    [ "index", "structcart.html#a750b5d744c39a06bfb13e6eb010e35d0", null ],
    [ "items", "structcart.html#a73a123be87859fa3b006119fc9f5b434", null ],
    [ "next", "structcart.html#a2165a556fdff3918c9de2ffdcf849158", null ]
];