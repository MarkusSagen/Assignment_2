var structcart =
[
    [ "index", "structcart.html#af47301d461d2eefa7f149e42214a4133", null ],
    [ "items", "structcart.html#a55f754e4bd1cac4554ace5521fa3dbfe", null ],
    [ "next", "structcart.html#a0c1730d535b56d3077d064c2e09be3b3", null ]
];