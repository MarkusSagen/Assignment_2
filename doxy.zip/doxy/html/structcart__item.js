var structcart__item =
[
    [ "amount", "structcart__item.html#a14236de313193a14b4dbdf442bcf2bb9", null ],
    [ "merch", "structcart__item.html#ae7b03fabfea4663543ecd548e55f915a", null ],
    [ "next", "structcart__item.html#a5e2b15421ef78d5a423b9e19ee1631a4", null ]
];