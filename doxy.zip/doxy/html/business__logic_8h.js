var business__logic_8h =
[
    [ "get_merch", "business__logic_8h.html#a85c584046682f54ead0e8e38c971a584", null ],
    [ "list_merch_aux", "business__logic_8h.html#ab26b804a4cf43a95024bf5db992b0e77", null ],
    [ "show_stock_aux", "business__logic_8h.html#a921fa6711ac15f28f1653f4292818dff", null ],
    [ "webstore_add_merch", "business__logic_8h.html#a9eb5d920caa39fa8536a75c80e6f7a7c", null ],
    [ "webstore_add_to_cart", "business__logic_8h.html#a7d69990df6ba38bfdd35b455748d3ede", null ],
    [ "webstore_calculate_cost", "business__logic_8h.html#af3c90f3ee529b31b858c8c7d5de9cf09", null ],
    [ "webstore_checkout", "business__logic_8h.html#aa85b25f1f77eab07496244fb3341c7df", null ],
    [ "webstore_create_cart", "business__logic_8h.html#a3e5a10f30bc14e50e1f1584bd93811d0", null ],
    [ "webstore_edit_merch", "business__logic_8h.html#a090b18052dc69e14fe456ae744d927f6", null ],
    [ "webstore_init", "business__logic_8h.html#a38f60ee0c8353a04549f2d5d17077ae2", null ],
    [ "webstore_is_already_item", "business__logic_8h.html#ac719e63646ffee15f18c9a30a2943369", null ],
    [ "webstore_is_no_item", "business__logic_8h.html#a118b0a7da3cc1bf3fcce470e16c2a1d9", null ],
    [ "webstore_menu", "business__logic_8h.html#a62b37cf5d6bf358059d8cde4e798c3eb", null ],
    [ "webstore_remove", "business__logic_8h.html#a830b945adaa01cc58bfcb9889f162046", null ],
    [ "webstore_remove_cart", "business__logic_8h.html#a58511d2f2d66379a7ae32ad9cd8debf9", null ],
    [ "webstore_remove_from_cart", "business__logic_8h.html#a90308dbde6e892b2ca285b0af685f026", null ],
    [ "webstore_remove_merch", "business__logic_8h.html#a0b2a2cbcda2584270cca4e61c2e774f8", null ],
    [ "webstore_replenish", "business__logic_8h.html#ad07dcb0bd24a95112b68101816050f5d", null ],
    [ "webstore_undo", "business__logic_8h.html#a20169c7f90fa26e082e258a5376aa2e5", null ]
];