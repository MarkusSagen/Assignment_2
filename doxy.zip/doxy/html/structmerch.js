var structmerch =
[
    [ "available", "structmerch.html#a6a37485bfdca8f2d8b517b6b08cde1b3", null ],
    [ "description", "structmerch.html#a8444d6e0dfe2bbab0b5e7b24308f1559", null ],
    [ "name", "structmerch.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "next", "structmerch.html#aee045b2f665b2a73b970154ffee31606", null ],
    [ "price", "structmerch.html#aef7c2446a93a7dc07f65981daf37fa65", null ],
    [ "stock", "structmerch.html#aa2f377dbb4b0ed26d7cd817be60f70dd", null ]
];