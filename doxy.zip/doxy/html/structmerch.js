var structmerch =
[
    [ "available", "structmerch.html#a02fe9990e8095029c0a3a2249e330848", null ],
    [ "description", "structmerch.html#acf8d3a8bd2bda336a8e13cdfa7a6ebc2", null ],
    [ "name", "structmerch.html#a426a04032dc18403613e6c6897fa1401", null ],
    [ "next", "structmerch.html#a6cd63fded68f58650c650daa3af73dc7", null ],
    [ "price", "structmerch.html#aa2100d7e0bf3b7e52720fbd9cdaf2b8f", null ],
    [ "stock", "structmerch.html#a3ace8a2a3c5c72d5c811408d73486511", null ]
];