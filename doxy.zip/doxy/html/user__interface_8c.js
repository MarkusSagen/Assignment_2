var user__interface_8c =
[
    [ "webstore_list_len", "user__interface_8c.html#ad6e974458818330ffb8aa1a45e5d9ae2", null ],
    [ "add_merch", "user__interface_8c.html#a0286e89a190965c11b14ed550194a048", null ],
    [ "add_to_cart", "user__interface_8c.html#a044d2473c70a723941a03e38f4f1e037", null ],
    [ "calculate_cost", "user__interface_8c.html#a9719a518e10b7b936cf16b6695454bd1", null ],
    [ "checkout", "user__interface_8c.html#a37ec4d7725d167cf0a430a09c62c9f1b", null ],
    [ "create_cart", "user__interface_8c.html#a60edbd46a07d0e5bca90572ada4e04d4", null ],
    [ "edit_merch", "user__interface_8c.html#a08fe16b019ff43acc0d7e8ac033b7df7", null ],
    [ "list_merch", "user__interface_8c.html#aea685f065401ac88d8225f7f7a81480e", null ],
    [ "remove_cart", "user__interface_8c.html#a1e5efbca9491318d87682168624bd0fb", null ],
    [ "remove_from_cart", "user__interface_8c.html#a5972b9a734b9d244d0e6be072076d06b", null ],
    [ "remove_merch", "user__interface_8c.html#a3a8ee0b9e8915fb70faf0ed25c1eaa71", null ],
    [ "replenish", "user__interface_8c.html#a26880b5f3661aeef2dbb749f89e4b9e7", null ],
    [ "show_stock", "user__interface_8c.html#a081d118f56a1dd8862e64859c477eeeb", null ],
    [ "webstore_menu", "user__interface_8c.html#a62b37cf5d6bf358059d8cde4e798c3eb", null ],
    [ "webstore_menu_ui", "user__interface_8c.html#a48f90e47807df8410811fa4d919dac81", null ]
];