var structstock =
[
    [ "amount", "structstock.html#a14236de313193a14b4dbdf442bcf2bb9", null ],
    [ "location", "structstock.html#a6a0d5603410d5eda93c0ff341966cce1", null ],
    [ "next", "structstock.html#a4798c719496e2c60a1ccb73ebec7108c", null ]
];