var structstock =
[
    [ "amount", "structstock.html#a073c21e5d04123c61a9a25be2f60df98", null ],
    [ "location", "structstock.html#a6957e33252ab3008dba5cec69408cb94", null ],
    [ "next", "structstock.html#a558109fc16680c8e425b5d8ca0b89e1a", null ]
];