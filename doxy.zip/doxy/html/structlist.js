var structlist =
[
    [ "fun", "structlist.html#a38d8fbdbb647c3d79759527d1480d278", null ],
    [ "last", "structlist.html#aa84133359bab9379d8655534244b0527", null ],
    [ "next", "structlist.html#af05e1662817f5aa024ad7148177ffd8c", null ],
    [ "size", "structlist.html#a439227feff9d7f55384e8780cfc2eb82", null ],
    [ "value", "structlist.html#a8e0c270a14cc4511175c78480705695c", null ]
];