var structlist =
[
    [ "fun", "structlist.html#a660aac621c5d8e2c0aeee5877d4bd161", null ],
    [ "last", "structlist.html#a3fd112c9024aba0d9cda3be94f8f4af5", null ],
    [ "next", "structlist.html#aa59b84b7e4118914f5f088fe5d1b7698", null ],
    [ "size", "structlist.html#af587fdfce9d601b6217ed4c2f02df477", null ],
    [ "value", "structlist.html#a59f5458d4ac80977fd0f8ae43ced74bc", null ]
];